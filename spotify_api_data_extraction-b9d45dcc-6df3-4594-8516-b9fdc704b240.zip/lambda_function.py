import json
import os 
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import boto3
from datetime import datetime

def lambda_handler(event, context):
    
    #environment variables
    client_id=os.environ.get('client_id')
    client_secret=os.environ.get('client_secret')
    
    #spotify authentication
    client_credentials_manager=SpotifyClientCredentials(client_id=client_id,client_secret=client_secret)
    
    #spotify authorization
    sp=spotipy.Spotify(client_credentials_manager=client_credentials_manager)
    playlists=sp.user_playlists('spotify')
    
    
    playlist_link="https://open.spotify.com/playlist/37i9dQZEVXbMDoHDwVN2tF?si=3a58ec60cb1b4754&nd=1&dlsi=3a8fcd396ae54619"
    playlist_uri=playlist_link.split("/")[4].split("?")[0]
    spotify_data=sp.playlist_tracks(playlist_uri)
    
    print(spotify_data)
    
    client=boto3.client('s3')
    
    filename= "spotify_raw_" + str(datetime.now()) + ".json"
    
    client.put_object(
        Bucket="my-spotify-etl-project",
        Key="raw_data/to_processed/" + filename,
        Body=json.dumps(spotify_data)
        )